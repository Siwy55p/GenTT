using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.RegularExpressions;
using TikTokGenerator.Models;

namespace TikTokGenerator.Services;

public interface IModelClient
{
    Task<ModelJsonResponse> GenerateJsonAsync(
        ModelJsonRequest request,
        GenerationDebugLogger? logger,
        CancellationToken cancellationToken);
}

public sealed record ModelJsonRequest(
    string Prompt,
    object Schema,
    string StageName,
    ShortGeneratorOptions Options,
    double Temperature,
    int MaxOutputTokens);

public sealed record ModelJsonResponse
{
    public string Provider { get; init; } = string.Empty;

    public string Model { get; init; } = string.Empty;

    public string StageName { get; init; } = string.Empty;

    public string SchemaName { get; init; } = string.Empty;

    public bool StrictSchema { get; init; }

    public string RawText { get; init; } = string.Empty;

    public string ResponseId { get; init; } = string.Empty;

    public int StatusCode { get; init; }

    public long ElapsedMilliseconds { get; init; }

    public int? InputTokens { get; init; }

    public int? OutputTokens { get; init; }

    public int? TotalTokens { get; init; }
}

public sealed class ModelClient : IModelClient
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true
    };

    private readonly HttpClient _httpClient;

    public ModelClient(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public Task<ModelJsonResponse> GenerateJsonAsync(
        ModelJsonRequest request,
        GenerationDebugLogger? logger,
        CancellationToken cancellationToken)
    {
        var provider = ResolveProvider(request.Options);
        return provider switch
        {
            "openai" => CallOpenAIAsync(request, logger, cancellationToken),
            "ollama" => CallOllamaAsync(request, logger, cancellationToken),
            _ => throw new InvalidOperationException($"Nieznany provider modelu AI: {provider}. Uzyj: auto, openai albo ollama.")
        };
    }

    private async Task<ModelJsonResponse> CallOpenAIAsync(
        ModelJsonRequest request,
        GenerationDebugLogger? logger,
        CancellationToken cancellationToken)
    {
        var apiKey = ResolveOpenAIApiKey(request.Options);
        if (string.IsNullOrWhiteSpace(apiKey))
        {
            throw new InvalidOperationException("Brakuje klucza OpenAI API. Ustaw OPENAI_API_KEY albo wybierz provider ollama.");
        }

        var model = ResolveOpenAIModel(request.Options);
        var schemaName = CreateSchemaName(request.StageName);
        var endpoint = new Uri(new Uri(ResolveOpenAIBaseUrl(request.Options).TrimEnd('/') + "/"), "responses");
        var body = CreateOpenAIRequestBody(request, model, schemaName);

        logger?.Info($"Calling OpenAI Responses endpoint={endpoint} model={model} stage={request.StageName}; promptChars={request.Prompt.Length}; schemaName={schemaName}; strictSchema=true; maxOutputTokens={request.MaxOutputTokens}; reasoningEffort={ResolveOpenAIReasoningEffort(request.Options)}");

        using var httpRequest = new HttpRequestMessage(HttpMethod.Post, endpoint);
        httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
        httpRequest.Content = JsonContent.Create(body, options: JsonOptions);

        var stopwatch = Stopwatch.StartNew();
        using var response = await _httpClient.SendAsync(httpRequest, cancellationToken);
        var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);
        stopwatch.Stop();

        logger?.Info($"OpenAI HTTP response stage={request.StageName}; status={(int)response.StatusCode}; elapsedMs={stopwatch.ElapsedMilliseconds}; bodyChars={responseBody.Length}");
        if (logger is not null)
        {
            await logger.SaveTextAsync($"openai-{request.StageName}-http-response.json", responseBody, cancellationToken);
        }

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException($"OpenAI zwrocilo blad HTTP {(int)response.StatusCode}: {responseBody}");
        }

        var parsed = ParseOpenAIResponse(responseBody);
        logger?.Info($"OpenAI model response stage={request.StageName}; responseId={parsed.ResponseId}; model={parsed.Model}; responseChars={parsed.RawText.Length}; inputTokens={parsed.InputTokens?.ToString() ?? string.Empty}; outputTokens={parsed.OutputTokens?.ToString() ?? string.Empty}; totalTokens={parsed.TotalTokens?.ToString() ?? string.Empty}");

        if (logger is not null)
        {
            await logger.SaveTextAsync($"openai-{request.StageName}-raw.txt", parsed.RawText, cancellationToken);
            await logger.SaveJsonAsync(
                $"model-call-{request.StageName}-summary.json",
                new
                {
                    provider = "openai",
                    parsed.Model,
                    request.StageName,
                    schemaName,
                    strictSchema = true,
                    promptChars = request.Prompt.Length,
                    responseChars = parsed.RawText.Length,
                    parsed.ResponseId,
                    parsed.InputTokens,
                    parsed.OutputTokens,
                    parsed.TotalTokens,
                    elapsedMs = stopwatch.ElapsedMilliseconds
                },
                cancellationToken);
        }

        return parsed with
        {
            Provider = "openai",
            StageName = request.StageName,
            SchemaName = schemaName,
            StrictSchema = true,
            StatusCode = (int)response.StatusCode,
            ElapsedMilliseconds = stopwatch.ElapsedMilliseconds
        };
    }

    private async Task<ModelJsonResponse> CallOllamaAsync(
        ModelJsonRequest request,
        GenerationDebugLogger? logger,
        CancellationToken cancellationToken)
    {
        var model = string.IsNullOrWhiteSpace(request.Options.OllamaModel)
            ? "qwen3:4b"
            : request.Options.OllamaModel;
        var body = new
        {
            model,
            prompt = request.Prompt,
            stream = false,
            format = request.Schema,
            think = false,
            options = new
            {
                temperature = request.Temperature,
                num_predict = request.MaxOutputTokens
            }
        };

        var endpoint = new Uri(new Uri(request.Options.OllamaBaseUrl.TrimEnd('/') + "/"), "api/generate");
        logger?.Info($"Calling Ollama endpoint={endpoint} model={model} stage={request.StageName}; promptChars={request.Prompt.Length}; schemaType={request.Schema.GetType().Name}; temperature={request.Temperature:0.###}; numPredict={request.MaxOutputTokens}");

        try
        {
            var stopwatch = Stopwatch.StartNew();
            using var response = await _httpClient.PostAsJsonAsync(endpoint, body, JsonOptions, cancellationToken);
            var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);
            stopwatch.Stop();
            logger?.Info($"Ollama HTTP response stage={request.StageName}; status={(int)response.StatusCode}; elapsedMs={stopwatch.ElapsedMilliseconds}; bodyChars={responseBody.Length}");
            if (logger is not null)
            {
                await logger.SaveTextAsync($"ollama-{request.StageName}-http-response.json", responseBody, cancellationToken);
            }

            if (!response.IsSuccessStatusCode)
            {
                throw new InvalidOperationException($"Ollama zwrocila blad HTTP {(int)response.StatusCode}: {responseBody}");
            }

            var ollamaResponse = JsonSerializer.Deserialize<OllamaGenerateResponse>(responseBody, JsonOptions)
                ?? throw new InvalidOperationException("Ollama zwrocila pusta odpowiedz.");
            logger?.Info($"Ollama model response stage={request.StageName}; responseChars={ollamaResponse.Response.Length}");

            if (logger is not null)
            {
                await logger.SaveTextAsync($"ollama-{request.StageName}-raw.txt", ollamaResponse.Response, cancellationToken);
                await logger.SaveJsonAsync(
                    $"model-call-{request.StageName}-summary.json",
                    new
                    {
                        provider = "ollama",
                        model,
                        request.StageName,
                        schemaName = request.StageName,
                        strictSchema = false,
                        promptChars = request.Prompt.Length,
                        responseChars = ollamaResponse.Response.Length,
                        elapsedMs = stopwatch.ElapsedMilliseconds
                    },
                    cancellationToken);
            }

            return new ModelJsonResponse
            {
                Provider = "ollama",
                Model = model,
                StageName = request.StageName,
                SchemaName = request.StageName,
                StrictSchema = false,
                RawText = ollamaResponse.Response,
                StatusCode = (int)response.StatusCode,
                ElapsedMilliseconds = stopwatch.ElapsedMilliseconds
            };
        }
        catch (HttpRequestException ex)
        {
            throw new InvalidOperationException(
                "Nie moge polaczyc sie z Ollama. Uruchom Ollama i wykonaj: ollama pull qwen3:4b",
                ex);
        }
    }

    private static Dictionary<string, object?> CreateOpenAIRequestBody(
        ModelJsonRequest request,
        string model,
        string schemaName)
    {
        var body = new Dictionary<string, object?>
        {
            ["model"] = model,
            ["input"] = request.Prompt,
            ["store"] = false,
            ["max_output_tokens"] = request.MaxOutputTokens,
            ["text"] = new
            {
                format = new
                {
                    type = "json_schema",
                    name = schemaName,
                    strict = true,
                    schema = request.Schema
                }
            }
        };

        var reasoningEffort = ResolveOpenAIReasoningEffort(request.Options);
        if (!string.IsNullOrWhiteSpace(reasoningEffort)
            && !reasoningEffort.Equals("none", StringComparison.OrdinalIgnoreCase))
        {
            body["reasoning"] = new { effort = reasoningEffort };
        }

        return body;
    }

    private static ModelJsonResponse ParseOpenAIResponse(string responseBody)
    {
        using var document = JsonDocument.Parse(responseBody);
        var root = document.RootElement;
        var status = ReadString(root, "status");
        if (!string.IsNullOrWhiteSpace(status)
            && !status.Equals("completed", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException($"OpenAI nie zakonczyl odpowiedzi statusem completed. Status={status}; Body={responseBody}");
        }

        var text = ExtractOpenAIText(root);
        if (string.IsNullOrWhiteSpace(text))
        {
            throw new InvalidOperationException($"OpenAI nie zwrocilo tekstu w odpowiedzi Responses API. Body={responseBody}");
        }

        var usage = root.TryGetProperty("usage", out var usageElement) ? usageElement : default;
        return new ModelJsonResponse
        {
            Model = ReadString(root, "model"),
            ResponseId = ReadString(root, "id"),
            RawText = text,
            InputTokens = ReadInt(usage, "input_tokens"),
            OutputTokens = ReadInt(usage, "output_tokens"),
            TotalTokens = ReadInt(usage, "total_tokens")
        };
    }

    private static string ExtractOpenAIText(JsonElement root)
    {
        if (root.TryGetProperty("output_text", out var outputText)
            && outputText.ValueKind == JsonValueKind.String)
        {
            return outputText.GetString() ?? string.Empty;
        }

        if (!root.TryGetProperty("output", out var output)
            || output.ValueKind != JsonValueKind.Array)
        {
            return string.Empty;
        }

        foreach (var item in output.EnumerateArray())
        {
            if (!item.TryGetProperty("content", out var content)
                || content.ValueKind != JsonValueKind.Array)
            {
                continue;
            }

            foreach (var contentItem in content.EnumerateArray())
            {
                if (contentItem.TryGetProperty("text", out var text)
                    && text.ValueKind == JsonValueKind.String)
                {
                    return text.GetString() ?? string.Empty;
                }
            }
        }

        return string.Empty;
    }

    private static string ResolveProvider(ShortGeneratorOptions options)
    {
        var configured = FirstNonEmpty(
            options.ModelProvider,
            Environment.GetEnvironmentVariable("TIKTOK_MODEL_PROVIDER"),
            Environment.GetEnvironmentVariable("MODEL_PROVIDER"));
        if (string.IsNullOrWhiteSpace(configured)
            || configured.Equals("auto", StringComparison.OrdinalIgnoreCase))
        {
            return string.IsNullOrWhiteSpace(ResolveOpenAIApiKey(options)) ? "ollama" : "openai";
        }

        return configured.Trim().ToLowerInvariant();
    }

    private static string ResolveOpenAIApiKey(ShortGeneratorOptions options)
    {
        return FirstNonEmpty(
            options.OpenAIApiKey,
            Environment.GetEnvironmentVariable("OPENAI_API_KEY"),
            Environment.GetEnvironmentVariable("OPENAI_API_KEY", EnvironmentVariableTarget.User),
            Environment.GetEnvironmentVariable("OPENAI_API_KEY", EnvironmentVariableTarget.Machine));
    }

    private static string ResolveOpenAIBaseUrl(ShortGeneratorOptions options)
    {
        return FirstNonEmpty(
            options.OpenAIBaseUrl,
            Environment.GetEnvironmentVariable("OPENAI_BASE_URL"),
            "https://api.openai.com/v1");
    }

    private static string ResolveOpenAIModel(ShortGeneratorOptions options)
    {
        return FirstNonEmpty(
            options.OpenAIModel,
            Environment.GetEnvironmentVariable("OPENAI_MODEL"),
            "gpt-5.6-terra");
    }

    private static string ResolveOpenAIReasoningEffort(ShortGeneratorOptions options)
    {
        return FirstNonEmpty(
            options.OpenAIReasoningEffort,
            Environment.GetEnvironmentVariable("OPENAI_REASONING_EFFORT"),
            "medium");
    }

    private static string FirstNonEmpty(params string?[] values)
    {
        return values.FirstOrDefault(value => !string.IsNullOrWhiteSpace(value))?.Trim() ?? string.Empty;
    }

    private static string CreateSchemaName(string stageName)
    {
        var normalized = Regex.Replace(stageName.ToLowerInvariant(), "[^a-z0-9_]+", "_");
        normalized = Regex.Replace(normalized, "_+", "_").Trim('_');
        return string.IsNullOrWhiteSpace(normalized) ? "model_output" : normalized;
    }

    private static string ReadString(JsonElement element, string propertyName)
    {
        return element.ValueKind == JsonValueKind.Object
            && element.TryGetProperty(propertyName, out var value)
            && value.ValueKind == JsonValueKind.String
                ? value.GetString() ?? string.Empty
                : string.Empty;
    }

    private static int? ReadInt(JsonElement element, string propertyName)
    {
        return element.ValueKind == JsonValueKind.Object
            && element.TryGetProperty(propertyName, out var value)
            && value.ValueKind == JsonValueKind.Number
            && value.TryGetInt32(out var result)
                ? result
                : null;
    }

    private sealed class OllamaGenerateResponse
    {
        public string Response { get; set; } = string.Empty;
    }
}
