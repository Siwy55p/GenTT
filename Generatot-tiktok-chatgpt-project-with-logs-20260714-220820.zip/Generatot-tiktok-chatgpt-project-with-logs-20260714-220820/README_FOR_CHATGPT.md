# Generator TikTokow - paczka dla ChatGPT

Cel paczki: analiza projektu w ChatGPT przegladarkowym.

Zawartosc:
- source/ - aktualny kod aplikacji TikTokGenerator, bez bin/obj i bez ciezkich narzedzi binarnych,
- tests/ - aktualne testy,
- logs/ - katalog Output z ostatnich uruchomien i debug/*.json/debug.log,
- GIT_STATUS.txt - stan roboczy repozytorium w momencie pakowania.

Pominiete celowo:
- .git i .vs,
- bin/ oraz obj/ poza logami Output,
- TikTokGenerator/Tools z ffmpeg/ffplay/ffprobe/Piper, bo same narzedzia maja setki MB i nie sa potrzebne do analizy kodu.

Wazny ostatni blad z GUI byl w:
logs/20260714-215611-Aplikacja AI, ktora robi notatki z nagran/debug/debug.log
logs/20260714-215611-Aplikacja AI, ktora robi notatki z nagran/debug/source-analysis-diagnostics.json

Nowszy run po poprawce jest w logs/20260714-220529-Aplikacja AI, ktora robi notatki z nagran/.
